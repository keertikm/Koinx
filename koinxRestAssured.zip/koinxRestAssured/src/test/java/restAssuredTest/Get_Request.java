package restAssuredTest;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Get_Request{

	@Test
	public void getReq() {

		RestAssured.baseURI = "https://x8ki-letl-twmt.n7.xano.io/api:gHPd8le5";

		RequestSpecification httpRequest = RestAssured.given();

		Response response = httpRequest.request(Method.GET, "api:gHPd8le5");

		int statusCode = response.getStatusCode();

		System.out.println("Response status code is" + statusCode);

		String responseBody = response.getBody().asString();

		Assert.assertTrue(responseBody.contains("USDT"));

	}
}