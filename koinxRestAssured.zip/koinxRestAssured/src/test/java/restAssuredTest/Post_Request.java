package restAssuredTest;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Post_Request {

	@Test
	public void postReq() {

		RestAssured.baseURI = "https://x8ki-letl-twmt.n7.xano.io/api:gHPd8le5";

		String Data = "{\r\n" + "\"coin1\": \"INR\",\r\n" + "\"coin2\": \"USDT\",\r\n" + "\"coin1Amount\": 300,\r\n"
				+ "\"coin2Amount\": 2\r\n" + "}";

		RequestSpecification httpRequest = RestAssured.given();

		httpRequest.header("Content-Type", "application/json");

		Response response = httpRequest.body(Data).post("api:gHPd8le5");

		int statusCode = response.getStatusCode();

		System.out.println("Response status code is" + statusCode);

		String responseBody= response.getBody().asString();
		
		Assert.assertTrue(responseBody.contains("1675270470670"));
		
			
	}

}
